#!/bin/bash

file=$1
if [ $# -eq 0 ]
then
	echo "No input file given"
elif [ ! -f $file ]
then
	echo "$file file doesn't exist"
else
	file=$1
	awk '!a[$0]++' $file
fi