#!/bin/bash

lowerCaseConversion()
{
	read -p "Enter a string : " string
#	echo ${string,,}
	string=${string,,}
	echo $string
}
#To check if user running script is one of root users or not
userRoot()
{
	root=`cut -d ":" -f 3 /etc/passwd`
	user=`id -u`
	echo $root
	echo $user
	# userIsRoot=0
	# for rootuser in $root_id; do
	# 	if [ $rootuser -eq $user_id ]
	# 	then
	# 		$userIsRoot=$user_id
	# 	fi
	# done
	# if [ $userIsRoot -ne 0 ]
	# then
	# 	echo $userIsRoot
	# 	echo "User is root"
	# 	#return true
	# else
	# 	echo "User is not root"
	# 	#return false
	# fi
	if [ $root -eq $user ]
	then
		echo "User is root"
		#return true
	else
		echo "User is not root"
		#return false
	fi
}

#To check if script is run by a root ( using sudo )

# user_root()
# {
# 	if [[ $EUID -eq 0 ]]; then
# 	   echo "This script is run by root" 
# 	else
# 		echo "This script is not run by root"
# 	fi
# }

userExists()
{
	read -p "Enter a username : " user
	getent passwd $user > /dev/null
	if [ $? -eq 0 ]
	then 
		echo "user exisits"
		#return true
	else
		echo "User does not exists"
		#return false
	fi
}
lowerCaseConversion 
userRoot
userExists
