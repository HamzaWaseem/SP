#!/bin/bash
files=( `ls` )
for fileName in ${files[@]}
do
	IFS=$'.' exten=( $fileName )
	if [ -d ${exten[1]} ]
	then
		IFS=$" "
		mv $fileName ${exten[1]}
	else
		IFS=$" "
		mkdir ${exten[1]}
		mv $fileName ${exten[1]}
	fi 
	
done