#!/bin/bash

file=$1
counter=0
even="evenfile"
odd="oddfile"
if [ $# -eq 0 ] 
then
	echo "No input file given"
elif [ ! -f $file ]
then
	echo "$file file doesn't exist"
else
	while read line
	do
		checkEven=$( expr $counter % 2 )
	 	if [ $checkEven -ne 0 ] 
	 	then
	 		echo $line >> $even
		else
			echo $line >> $odd
		fi
		(( counter ++ ))
	done < $file
fi