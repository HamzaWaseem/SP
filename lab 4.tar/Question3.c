#include<stdlib.h>
#include<stdio.h>
#include<setjmp.h>
int counter=0;
static jmp_buf envbuf;
void haveFun()
{ 
	printf("haveFun function \n"); 
	printf("Value of Counter: %d", counter);
	printf("\n");
	counter++; 
}
void firstSetJump()
{ 
	printf("firstSetJump function\n"); 
	printf("Value of Counter: %d", counter);
	printf("\n");
	counter++; 
}
int main()
{ 
	int i = 0; 
	for(i; i <5; i++)
	{
		printf("main function \n");
		if (counter == 0 && (i = setjmp(envbuf)) == 0)
			firstSetJump(); 
		haveFun();
	}
	return 0;  
}
