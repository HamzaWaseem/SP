#include <stdio.h>
#include <stdlib.h>

int main()
{
	int *arr = (int*) malloc (sizeof(int)*10);
	arr[0]=1;
	arr[1]=2;
	arr[2]=3;
	arr[3]=4;
	arr[4]=5;
	arr[5]=6;
	arr[6]=7;
	arr[7]=8;
	arr[8]=9;
	arr[9]=10;
	for (int i=0;i<10;i++)
	{
		printf("%i",arr[i]);
		printf("\n");
	}
	printf("Now printing resized array :  \n");
	arr = (int*) realloc (arr,sizeof(int)*20);
	arr[10]=11;
	arr[11]=12;
	arr[12]=13;
	arr[13]=14;
	arr[14]=15;
	arr[15]=16;
	arr[16]=17;
	arr[17]=18;
	arr[18]=19;
	arr[19]=20;
	for (int i=0;i<20;i++)
	{
		printf("%i",arr[i]);
		printf("\n");
	}
	free(arr);

	return 0;
}