#!/bin/bash
print_table ()
{
	declare -i ctr
	if [ $# = 1 ]
	then
		for ctr in `seq 1 10`
		do
			echo "$1 x $ctr = `expr $1 \* $ctr`"
		done
	elif [ $# = 3 -a $2 == '-e'	]
	then
		for ctr in `seq 1 $3`
		do
			echo "$1 x $ctr = `expr $1 \* $ctr`"
		done
	elif [ $# = 3 -a $2 == '-s'	]
	then
		for ctr in `seq $3 10`
		do
			echo "$1 x $ctr = `expr $1 \* $ctr`"
		done
	elif [ $# = 5 -a $2 == '-s' -a $4 == '-e' ]
	then
		for ctr in `seq $3 $5`
		do
			echo "$1 x $ctr = `expr $1 \* $ctr`"
		done
	elif [ $# = 6 -a $2 == '-s' -a $4 == '-e' -a $6 == '-r' ]
	then
		declare -i i
		i=$5
		while [ $i -ge $3 ]
		do
		{
			echo "$1 x $i = `expr $1 \* $i`"
			i=$(($i-1))
		}	
			#statements
		done
	fi
}

if [ $# = 0 ]
then
	echo "No arguement is given"
elif [ $# -gt 6 ]
 then
	echo "Arguements are more than 6"
else
	print_table $@
fi