#!/bin/bash

showAllOwners()
{
	user=$1
		for i in `ls`
			do
				set `ls -li $i`
				shift
				if [ -f $i ]
				then
					if [ $user = $3 ]
					then
					owner = $3
					shift
					echo "FileName: " $9
					echo "FileOwner: " $owner
					fi
				fi
			done
	
}
bool=0
if [ $# -eq 0 ]
	then
	echo "NO arguments"
elif [ $# -gt 1 ]
	then
	echo "Invalid arguments"
else
	cd ~/
	showAllOwners $1
fi
