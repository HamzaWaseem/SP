#!/bin/bash

Process()
{
	file=$1
	set `ps -all -A | grep $file`
	if [ $? -eq 0 ]
	then
	pid = $4
	ppid = $5
	echo "PID: " $pid
	shift 5
	echo "Name: " $9
	echo "PPID: " $ppid
	echo "STATE: running"
	fi
}
bool=0
if [ $# -eq 0 ]
	then
	echo "No argument given"
	bool=1
fi

if [ $# -gt 1 ]
	then
	echo "Invalid arguments given"
	bool=1
fi
if [ $bool -eq 0 ]
then
	count=`ps -all -A | grep $1 | wc -l`
	if [ $count -gt 0 ]
	then
		Process $1
	fi
fi

